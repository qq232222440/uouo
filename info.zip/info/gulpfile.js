// 引入 gulp
// npm install --save-dev gulp-babel babel-preset-es2015 引入babel
var gulp = require('gulp');
var fs = require('fs');
var path = require('path')
// 加载编码转换模块  
var iconv = require('iconv-lite'); 
// 引入组件
var htmlmin = require('gulp-htmlmin'), //html压缩
    htmlminify = require("gulp-html-minify"),
    imagemin = require('gulp-imagemin'),//图片压缩
    pngcrush = require('imagemin-pngcrush'),
    minifycss = require('gulp-minify-css'),//css压缩
    md5 = require('gulp-md5-plus'),
    os = require('os'),
    sass = require('gulp-ruby-sass'),
    inlinesource = require('gulp-inline-source'),
    fileinclude = require('gulp-file-include'),//插入文件
    cheerio = require('gulp-cheerio'),
    gulpOpen = require('gulp-open'),
    babel = require('gulp-babel'),//es6转换
    clean = require('gulp-clean'),//文件清除
    jshint = require('gulp-jshint'),//js检测
    uglify = require('gulp-uglify'),//js压缩
    concat = require('gulp-concat'),//文件合并
    rename = require('gulp-rename'),//文件更名
    connect = require('gulp-connect'),
    base64s = require('gulp-base64'),
	rev = require("gulp-rev"),
	revreplace = require("gulp-rev-replace"),
    notify = require('gulp-notify');//提示信息

var host = {
    path: 'dest/',
    port: 3000,
    html: 'index.html'
};
//mac chrome: "Google chrome",
var browser = os.platform() === 'linux' ? 'Google chrome' : (
    os.platform() === 'darwin' ? 'Google chrome' : (
        os.platform() === 'win32' ? 'chrome' : 'firefox'));
var pkg = require('./package.json');
 //压缩html
gulp.task('html', function() {
    return gulp.src('src/*.html')
        .pipe(htmlmin({collapseWhitespace: true}))
        .pipe(gulp.dest('./dest'))
        .pipe(connect.reload())
        .pipe(notify({ message: 'html task ok' }));
});
gulp.task('htmls' ,['imgto64','inlinesource',"css","writejs"], function(){
	var manifest = gulp.src("./dest/js/rev-manifest.json")
		
	return gulp.src('./dest/*.html')
	.pipe( revreplace({
		manifest: manifest,
		arr:["base","qdruck"]//添加js链接替换关键字
	}))
	.pipe( gulp.dest('./dest') );
   /*  gulp.src("dest/*.html")
        .pipe(htmlminify())
        .pipe(gulp.dest("./dest")) */

});
// 压缩图片
gulp.task('img', function() {
    return gulp.src('src/image/*.png')
        .pipe(imagemin({
            progressive: true,
            svgoPlugins: [{removeViewBox: false}],
            use: [pngcrush()]
        }))
        .pipe(gulp.dest('dest/image/'))
        .pipe(notify({ message: 'img task ok' }));
});

// 合并、压缩、重命名css
gulp.task('css',function() {
    var cssSrc='src/sass/*.scss',
        cssDst = 'dest/css';
    return gulp.src('src/css/*.css')
        // .pipe(sass({ style: 'compressed'}))
        .pipe(gulp.dest(cssDst))
        // .pipe(rename({ suffix: '.min' }))
        .pipe(minifycss())
        .pipe(gulp.dest(cssDst))
        .pipe(connect.reload()) 
        .pipe(notify({ message: 'css task ok' }));
});

// 检查js
gulp.task('lint', function() {
    return gulp.src('src/js/**/*.js')
        .pipe(jshint())
        .pipe(jshint.reporter('default'))
        .pipe(notify({ message: 'lint task ok' }));
});

// 合并、压缩js文件
gulp.task('js', function() {

    return gulp.src('src/js/**/*.js')
        .pipe(babel({presets:['es2015']}))
		.pipe(rev())
        // .pipe(concat('all.js'))
        .pipe(gulp.dest('dest/js'))
        // .pipe(rename({ suffix: '.min' }))
        .pipe(uglify())
		
		.pipe(rev.manifest())
        .pipe(gulp.dest('dest/js'))
		

        .pipe(connect.reload())
        .pipe(notify({ message: 'js task ok' }));
});
//生成js文件
//
gulp.task("writejs",["js"],function(){
	
	let config = require('./dest/js/rev-manifest.json')
	//let file = path.join(__dirname,'/src/js/config.js')
	let nfile = path.join(__dirname,'/dest/js/config.js')
	
	let str =''
	/* fs.readFile(file,function(err,data){
		if(err){
			console.warn(err)
		}
		else
		{
			str = iconv.decode(data, 'gbk');  
			var len = str.indexOf("revision");
			///requirejs.__requirejsConfig = 
			
		}
	})
 */
 var obj = {};
	for(var item in config){
		console.log("1",item,config[item])
		var arr= config[item].split('.');
		
		obj[item] = arr[1];
	}
	let abc = JSON.stringify(obj)
	var txt = `requirejs.__requirejsConfig = {
			"baseUrl": window.location.href+"/",//location href
			"prefix":'js/',//调用路径
			"revision": ${abc},
			"revrev": "1",
			"combo":{
				"url": window.location.href,
				"deps":{
					"apps.js":["lib/zepto.js","lib/juicer.js","common/service.js","api.js","newslist.js","pageable.js"],
					"lib/juicer.js":[],
					"lib/zepto.js":[],
					"common/service.js":["lib/zepto.js"],
					"api.js":["common/service.js"],
					"newslist.js":["lib/zepto.js","lib/juicer.js","api.js"],
					"util/act/page.js":[],
					"pageable.js":["util/act/gesture.js", "util/act/page.js", "lib/zepto.js"],
					"util/act/gesture.js":["lib/zepto.js"]
				}
			}
		}
	`

	fs.appendFile(nfile,txt,function(err){
		if(err)
		{
			console.log(err)
		}
		else
		{
			console.log("ok");
		}
	})

	
	
})
//将js加上10位md5,并修改html中的引用路径，该动作依赖js
gulp.task('md5:js', ['js'],function (done) {
    gulp.src('dest/js/**/*.js')
        .pipe(md5(10, 'dest/*.html'))
        .pipe(gulp.dest('dest/js'))
        .on('end', done);
});
//将css加上10位md5，并修改html中的引用路径，该动作依赖css
gulp.task('md5:css',['css'] ,function (done) {
    gulp.src('dest/css/*.css')
        .pipe(md5(10, 'dest/*.html'))
        .pipe(gulp.dest('dest/css'))
        .on('end', done);
});

//用于在html文件中直接include文件
gulp.task('fileinclude',function (done) {
    gulp.src(['src/*.html'])
        .pipe(fileinclude({
            prefix: '@@',
            basepath: '@file'
        }))
        .pipe(gulp.dest('dest'))
        .pipe(connect.reload())
        .on('end', done)
});
//修改js链接方法
//gulp.task('indexHtml', function() {
//    //return gulp.src('src/*.html')
//    //    .pipe(cheerio(function ($) {
//    //        $('head script').remove();
//    //        $('head').append('<script src="./js/base.js"></script>');
//    //    }))
//    //    .pipe(gulp.dest('dest/'));
//    return;
//});
//js css 插入页面
gulp.task('inlinesource',['imgto64',"css","writejs"],function(){
    return gulp.src('./dest/*.html')
        .pipe(inlinesource())
        .pipe(gulp.dest('dest/'))
})
gulp.task('clean', function (done) {
    gulp.src(['dest'])
        .pipe(clean())
});
gulp.task('open', function (done) {
   /*  gulp.src('')
        .pipe(gulpOpen({
            app: browser,
            uri: 'http://192.168.0.85:3000/'
        }))
        .on('end', done); */
});
gulp.task('connect', function () {
    console.log('connect------------');
    connect.server({
        root: host.path,
        port: host.port,
        livereload: true
    });
});
gulp.task('imgto64',['css'],function(){
    return gulp.src("dest/css/*.css")
        .pipe(base64s({
            extensions: ['png'],
            maxImageSize: 20 * 1024, // bytes
            debug: false
        }))
        .pipe(gulp.dest('dest/css'))
        .pipe(notify({ message: 'base64 task complete' }));
})
//清除
gulp.task('cleans',['clean'], function() {
    gulp.run('connect','img', 'css','fileinclude','lint', 'js','html', 'htmls', 'md5:css', 'md5:js','open',"inlinesource");
});
// 默认任务
gulp.task('default', function(){
    gulp.run('connect','img', 'css','fileinclude','lint', 'js','html',  'htmls', 'md5:css', 'md5:js','open',"inlinesource","writejs");
    // 监听html文件变化
    // gulp.watch('dest/*.html',['fileinclude'], function(){
    //     gulp.run('htmls');
    // });

    // // Watch .css files
    // gulp.watch('src/css/*.css');

    // // Watch .js files
    // gulp.watch('src/js/**/*.js');

    // Watch image files
    //gulp.watch('src/images/*', ['img']);
});
// 默认任务
gulp.task('dev',function(){
    gulp.run('connect',"imgto64",'css','js',"writejs",'fileinclude','inlinesource',"htmls",'open');
  //  gulp.run('connect','img','css','fileinclude', 'lint', 'js','html',  'open',"inlinesource","imgto64");

    // // 监听html文件变化
    // gulp.watch('dest/*.html',["imgto64",'css','js','fileinclude',"inlinesource"], function(){
    //     gulp.run('html');
    // });

    // // Watch .css files
    // gulp.watch('src/css/*.css', ['css']);

    // // Watch .js files
    // gulp.watch('src/js/**/*.js', ['lint', 'js']);
    
    //// Watch image files
    //gulp.watch('src/images/*', ['img']);
});

gulp.task('help',function(){
    console.log('gulp clean',"清除所有");
    console.log('gulp help',"gulp参数说明");
    console.log('gulp dev',"测试环境");
    console.log('gulp ',"开发环境");
})
