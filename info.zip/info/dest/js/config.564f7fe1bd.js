"use strict";

var abc = {
	"baseUrl": window.location.href + "/", //location href
	"prefix": 'js/', //����·��
	"revision": {
		"apps.js": "",
		"lib/zepto.js": "1",
		"lib/juicer.js": "",
		"common/service.js": "",
		"api.js": "",
		"newslist.js": ""
	},
	"revrev": "1",
	"combo": {
		"url": window.location.href,
		"deps": {
			"apps.js": ["lib/zepto.js", "lib/juicer.js", "common/service.js", "api.js", "newslist.js"],
			"lib/juicer.js": [],
			"lib/zepto.js": [],
			"common/service.js": ["lib/zepto.js"],
			"api.js": ["common/service.js"],
			"newslist.js": ["lib/zepto.js", "lib/juicer.js", "api.js"]
		}
	}
};