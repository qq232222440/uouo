"use strict";

define(["lib/zepto.js"], function ($) {
    //var UNPOST_KEY = "qd_POST_DATA",
    //    GET_KEY_PREFIX = "qd_GET_";
    var service = {
        ajax: function ajax(options) {
            if (options.type == "post") {
                this.doPost(options);
            } else {
                this.doGet(options);
            }
        },
        doPost: function doPost(options) {
            $.ajax(options);
        },
        doGet: function doGet(options) {
            var key = options.url + JSON.stringify(options.data);
            var callback = options.success;
            options.success = function (result) {
                callback(result, key);
            };
            $.ajax(options);
        }
    };
    return service;
});