"use strict";

define([], function () {
    var a = function a(_a, b) {
        this.dom = _a, this.options = b || {};
    };
    return a.prototype = {
        constructor: a,
        resize: function resize() {
            this._cacheW = window.innerWidth, this._cacheH = window.innerHeight;
        },
        show: function show() {
            this.dom.css("-webkit-transform", void 0), this.dom.removeClass("current").removeClass("prev").removeClass("next").addClass("current");
        },
        hide: function hide(a) {
            this.dom.css("-webkit-transform", void 0), "prev" == a ? this.dom.removeClass("current").removeClass("prev").removeClass("next").addClass("prev") : "next" == a && this.dom.removeClass("current").removeClass("prev").removeClass("next").addClass("next");
        },
        prepare: function prepare(a) {
            var b = this,
                c = this.dom.attr("data-backimg");
            c && this.dom.css("background-image", c);
            var d = this.dom.find("img");
            if (d.length && "" == d.attr("src")) {
                d.css("width", "100%").css("height", "5rem");
                var e = new Image();
                e.onload = function () {
                    d.attr("src", d.attr("data-pic-src")).css("width", null).css("height", null).css("max-width", "100%").css("max-height", "100%"), d[0].onload = null;
                }, e.src = d.attr("data-pic-src");
            }
            setTimeout(function () {
                b._cacheW == window.innerWidth && b._cacheH == window.innerHeight || b.resize();
            }, a || 200);
        },
        showing: function showing(a) {
            "ver" == this.options.dir ? this.dom.css("-webkit-transform", "translateY(" + a + "px)") : this.dom.css("-webkit-transform", "translateX(" + a + "px)");
        }
    }, a;
});