requirejs.__requirejsConfig = {
			"baseUrl": window.location.href+"/",//location href
			"prefix":'js/',//调用路径
			"revision": {"api.js":"ea604b1c5b","apps.js":"4af4bd4236","base.js":"ad78645b97","common/service.js":"aee8014605","config.js":"564f7fe1bd","lib/juicer.js":"6851b40bfe","lib/qdruck.js":"dc649432e8","lib/zepto.js":"d6ce709389","newslist.js":"710e83479a","pageable.js":"d2ebb2547c","util/act/gesture.js":"b4247558df","util/act/page.js":"0d055ee143"},
			"revrev": "1",
			"combo":{
				"url": window.location.href,
				"deps":{
					"apps.js":["lib/zepto.js","lib/juicer.js","common/service.js","api.js","newslist.js","pageable.js"],
					"lib/juicer.js":[],
					"lib/zepto.js":[],
					"common/service.js":["lib/zepto.js"],
					"api.js":["common/service.js"],
					"newslist.js":["lib/zepto.js","lib/juicer.js","api.js"],
					"util/act/page.js":[],
					"pageable.js":["util/act/gesture.js", "util/act/page.js", "lib/zepto.js"],
					"util/act/gesture.js":["lib/zepto.js"]
				}
			}
		}
	