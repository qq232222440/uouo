"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

define(["common/service.js", "lib/zepto.js"], function (service, $) {
    //var baseUrl = window.location.origin+"/";
    if (window.location.origin.indexOf("3000") > 0 || window.location.origin.indexOf("3001") > 0) {
        var baseUrl = "http://qdnav.cn:8080/api/";
    } else {
        var baseUrl = window.location.origin + "/api/";
    }

    var addLinkStr = $.isPC() ? "" : "?token=1";
    var api = {
        get: function get(url, param, success, error, beforeSend) {
            this.ajax("GET", url, param, success, error, beforeSend);
        },
        post: function post(url, param, success, error, beforeSend) {
            this.ajax("POST", url, JSON.stringify(param), success, error, beforeSend);
        },
        ajax: function ajax(type, url, param, success, _error, beforeSend) {
            url = baseUrl + url;
            if (location.protocol == "http:") {
                if (type == "GET") {
                    if (window.location.origin.indexOf("qdnav") > 0) {
                        url = url + "?" + $.param(param);
                    } else {
                        //  url = url+"?"+$.param(param);
                        url = "/proxy?url=" + url + "?" + $.param(param); //跨域
                    }
                }
            } else {
                if (window.location.origin.indexOf("qdnav") > 0) {
                    url = url;
                } else {
                    url = '/proxy?url=' + url;
                }
            }
            var options = {
                url: url,
                type: type || "GET",
                data: param,
                timeout: 120000,
                success: success,
                beforeSend: beforeSend,
                cache: type == "GET" ? false : true,
                error: function error(xhr, type) {
                    if (_error) {
                        _error(xhr, type);
                    } else {
                        parseError(xhr, type, url);
                    }
                },
                dataType: "json"
            };
            function parseError(xhr, type, url) {
                console.error(xhr, type, url);
            }
            service.ajax(options);
        },
        "initH5": function initH5(ch, success, error) {
            var ch = ch || "normal";
            //导航的信息
            this.get('browser/inith5', { "clienttype": "1", "ch": ch, "ver": "1" }, success, error);
            //this.get('test.json',{"clienttype":"1","ch":"ch1"},success,error);
        },
        "associateWord": function associateWord(key, success, error) {
            //关键字查询
            this.get('browser/associateword', { keyword: key, "ch": "normal", "ver": "1" }, success, error);
        },
        //type,platform,city,area,prov,
        "sign": function sign(success, error) {
            //注册
            $.ajax({
                url: 'http://bdp.deeporiginalx.com/v2/au/sin/g' + addLinkStr,
                type: "POST",
                data: JSON.stringify({
                    "utype": 2,
                    "platform": 3,
                    "province": "北京市",
                    "city": "北京市",
                    "district": "东城区"
                }),
                beforeSend: function beforeSend(xhr) {},
                contentType: "application/json",
                success: success,
                error: error
            });
        },
        "login": function login(uid, pwd, success, error) {
            $.ajax({
                url: "http://bdp.deeporiginalx.com/v2/au/lin/g" + addLinkStr,
                type: "POST",
                data: JSON.stringify({
                    "uid": uid,
                    "password": pwd
                }),

                beforeSend: function beforeSend(xhr) {},
                contentType: 'application/json',
                success: success,
                error: error
            });
        },
        "newslist": function newslist(cid, currTime, page, success, error, beforeSend) {
            $.ajax({
                url: "http://bdp.deeporiginalx.com/v2/ns/fed/l",
                type: "GET",
                data: { "cid": cid, "tcr": currTime, "tmk": page },
                beforeSend: beforeSend,
                success: success,
                error: error
            });
        },

        "cloverPost": function cloverPost(url, params, callback) {

            var xhr = new XMLHttpRequest();

            xhr.onload = function () {
                alert(typeof xhr === "undefined" ? "undefined" : _typeof(xhr));
                var data = $.parseJSON(xhr.responseText);
                if (data == null || typeof data == 'undefined') {
                    data = $.parseJSON(data.firstChild.textContent);
                }
                alert(xhr.getAllResponseHeaders());
                alert(xhr.getResponseHeader("Accept-Encoding"));
                //需要手动格式化
            };
            xhr.onerror = function (e) {};
            xhr.open("POST", url);
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.setRequestHeader("Authorization", null);
            //xhr.overrideMimeType("text/json");
            xdr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
            xhr.send(params); //这里的数据是 a=1&b=2这样的
        }
    };
    return api;
});