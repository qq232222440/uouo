define(["lib/zepto.js","lib/juicer.js","api.js","newslist.js","pageable.js","util/act/page.js"],function($,tpl,api,nlist,pageable,page){
	var navs;
	var juicer = tpl;
	return {
		init:function(k)
		{
			//a.init({
			//	cityId:k.cityId
			//});
			var ch = this.getUrlParam("ch");
			navs = this;
			
			for (var c = $(".page"), d = [], e = 0; e < c.length; e++)
            {
				d.push(new page($(c[e])));
			}
			console.log("page",d)
			new pageable(d,$(".icon-wrapper"),{
				margindrag: !0,
				changed: function(a) {
					$($(".list-ico li").removeClass("active")[a]).addClass("active"),
					$($(".list-text li").removeClass("active")[a]).addClass("active")
				}
			})
			function testLen(dt)
			{
				return dt.length>0;
			}
			var localStorage = window.localStorage,time=new Date().getTime();

			if(localStorage.getItem("time"))
			{
				var oldTime = localStorage.getItem("time");
				if(time-oldTime>3000000)
				{
					localStorage.removeItem("newsDt");
					localStorage.removeItem("time");
				}
			}
			else
			{
				localStorage.setItem("time",time);
			}

			if(localStorage.getItem("newsDt"))
			{
				var dt = JSON.parse(localStorage.getItem("newsDt"));
				fillNav(dt)
			}
			else
			{

				api.initH5(ch,function(data){
					var dt = data.data;
					if(data.success&&!dt.hasOwnProperty("sitenav"))
					{
						//create news
						nlist.init();
						return false;
					}
					if(data.success&&testLen(dt.searchengine)&&testLen(dt.hotword)&&testLen(dt.sitenav))
					{
						localStorage.setItem("newsDt",JSON.stringify(data));
					}
					fillNav(data)
				});
			}

			function fillNav(data)
			{
				//点击搜索
				navs.onInputFunc.call(navs,data.data.searchengine||"");
				//创建热词刷新
				navs.createKeyWordRefresh.call(navs,{list:data.data.hotword} );
				//输入框关键词联想
				navs.createKeyWord.call(navs,{searchhot:data.data.list});
				//热门导航
				navs.createHotSite.call(navs,data.data.hotsite);
				//热点网址导航
				//navs.createNewsNav.call(navs,{sitenav:dt.sitenav});
				//banner
				navs.createBanner.call(navs,data.data.banner);
				//create news
				nlist.init();
			}

			this.gotop();
		},
		createBanner:function(data){
			if(!data)
			{
				return false;
			}
			navs.$el(".banner-pic").setAttribute("src",data[0].image);
			navs.$el(".banner>a").setAttribute("href",data[0].url);
			var img = navs.$el(".banner>a").getElementsByTagName("img")[0];

			if(img.naturalWidth==0)
			{
				closeBanner();
			}
			else
			{
				navs.$el(".banner").style.display="block";
			};
			navs.$el(".banner-close").onclick = function(){
				closeBanner();
			};
			function closeBanner()
			{
				navs.$el(".banner").style.display="none";
			};
		},
		createKeyWordRefresh:function(data)
		{
			var tpl = document.getElementById("refresh-word").innerHTML;
			data.list.forEach(function(dd){
				if(dd.url=="")
				{
					var link = navs.$el('.j-oninput').getAttribute("data-link");
					dd.url=link+dd.keyword;
				}
			})
			navs.$el(".hotnews>ul").innerHTML=juicer(tpl,{"list":getRandArr(data.list,5)});
			var refreshBtn = navs.$el(".btn-refresh");
			refreshBtn.addEventListener("click",function(){
				var arr = getRandArr(data.list,5);
				navs.$el(".hotnews>ul").innerHTML=juicer(tpl,{"list":arr});
			})
			function getRandArr(arr, num) {
				var returnArr = [],initArr=arr;
				for (var i = 0; i<num; i++) {
					if (initArr.length>0) {
						var idx = Math.floor(Math.random()*initArr.length);
						returnArr[i] = initArr[idx];
					}
				}
				return returnArr.filter(onlyUnique);
			}
			function onlyUnique(value, index, self) {
				return self.indexOf(value) === index;
			}
		},
		//createNewsNav:function(data){
		//	var tpl = document.getElementById("tpl").innerHTML;
		//	navs.$el(".item-list").innerHTML=juicer(tpl,data);
		//},
		createKeyWord:function(data)
		{
			var solist =  navs.$el('.so-list'),
				onInput = navs.$el('.j-oninput'),
				clearBtn = navs.$el(".btn-clear");
			var flag = false;
			onInput.addEventListener("click",function(){
				//	solist.style.display = "block";
				getInputData();

			});
			onInput.addEventListener("input",function(){
				if(this.value.length>0)
				{
					clearBtn.style.display="block";
				}
					if(!flag)
					{
						getInputData();
					}
			});
			//get data
			function getInputData()
			{
				var val = onInput.value,t_start=0;
				api.associateWord(val,function(data){
					flag = true;

					//数据返回失败为false
					if(!data.success)
					{
						return false;
					}
					solist.style.display = "block";
					if(data.data.list.length==0)
					{
						solist.style.display = "none";
					}
					t_start = data.timestamp;//服务器返回时间
					var list = data.data.list;
					//if(list&&list.length>0)
					//{
					//	list.forEach(function(dd){
					//		var datalink = onInput.getAttribute("data-link");
					//		var link = datalink.indexOf("searchTerms")>0?datalink.replace("{searchTerms}",dd.name):datalink+dd.name;
					//		dd.url = dd.url.length>0?dd.url:link;
					//	})
					//}



					var tpl = document.getElementById("tpl-hot-keyword").innerHTML;
					navs.$el(".so-list>ul").innerHTML=juicer(tpl,{searchhot:list});
					var lia = document.querySelectorAll('.so-list>ul>li>a');
					for(var i=0;i<lia.length;i++)
					{
						lia[i].addEventListener("click",function(e){
							solist.style.display = "none";
							var datalink = onInput.getAttribute("data-link");
							var link = datalink.indexOf("searchTerms")>0?datalink.replace("{searchTerms}",e.target.innerText):datalink+e.target.innerText;
							onInput.value="";
							window.location.href=link;
						});
					}
					setTimeout(function(){
						flag = false;
					},700);
				})
			}
			navs.$el(".btn-close").addEventListener("click",function(){
				solist.style.display = "none";
			})
			clearBtn.addEventListener("click",function(){
				onInput.value = "";
				clearBtn.style.display="none";
				solist.style.display = "none";
			});
			//onInput.addEventListener("click",function(){
			//	solist.style.display = "block";
			//});
		},
		createHotSite:function(data){
			navs.$el(".top-menu").style.display="block";
			var dt=data,arr=[],len=dt.length,num=len%4==0?len-4:len-len%4;
			dt.forEach(function(dd,i){
				if(dd.sort)
				{
					arr[dd.sort-1] = dd
				}
			})
			arr.forEach(function(dd,i){
				if(i<num)
				{
					dd.cls = "bl";
				}
			})
			var tpl = document.getElementById("tpl-hot").innerHTML;
			navs.$el(".top-menu-list").innerHTML=juicer(tpl,{hotsite:arr});
		},
		gotop:function(){
			//var topIcon = document.querySelector(".btn-top");
			//function showTopIcon(){
			//	document.body.scrollTop > 400 ? topIcon.style.display = "block" : topIcon.style.display = "none";
			//}
			//topIcon.onclick = function() {
			//	window.scrollTo(0, 0)
			//}
			//window.addEventListener("scroll", showTopIcon);
		},
		onInputFunc:function(data){
			var onInput= this.$el(".j-oninput");
			onInput.setAttribute("data-link",data[0].url);
			this.$el(".btn-search").addEventListener("click",function(){

				navs.$el(".so-list").style.display="none";
				var url =  (data[0].url).indexOf("searchTerms")>0?data[0].url.replace("{searchTerms}",onInput.value):data[0].url+onInput.value;
				onInput.value="";
				window.location.href=url;
			})
		},
		$el:function(elem){
			return document.querySelector(elem);
		},
		getUrlParam:function(strName){
			var strHref = window.location.href;
			var intPos = strHref.indexOf("?");
			var strRight = strHref.substr(intPos + 1);

			var arrTmp = strRight.split("&");
			for(var i = 0; i < arrTmp.length; i++)
			{
				var arrTemp = arrTmp[i].split("=");
				if(arrTemp[0].toUpperCase() == strName.toUpperCase()) return arrTemp[1].replace(/#/, "");
			}

			return "";
		}
	}
})