define(["util/act/gesture.js", "util/act/page.js", "lib/zepto.js"], function(gesture, b, c) {
    function d(a, b) {
        var c = "h" == this.dir ? a : b
          , d = this.prev()
          , e = this.next()
          , f = this.current();
        e != g && c < -this.hold ? this.nextPage() : d != g && c > this.hold ? this.prevPage() : (f.show("current"),
        d.hide("prev"),
        e.hide("next"),
        this.options.bigBuffer && (this.prev(2).hide("prev2"),
        this.next(2).hide("next2")))
    }
    function e(a, b) {
        var c = "h" == this.dir ? a : b
          , d = "h" == this.dir ? window.innerWidth : window.innerHeight;
        this.options.margindrag && (c > 0 && this.prev() == g || 0 > c && this.next() == g) || (this.prev().showing(c - d, "prev", c),
        this.current().showing(c, "current", c),
        this.next().showing(c + d, "next", c),
        this.options.moving && this.options.moving(c, b))
    }
    function f(b, c, g) {
        this.options = g || {},
        this.hold = g.hold || 20,
        this.pages = b,
        this._currentIndex = this.options.startIndex || 0;
        var h = this;
        this.dir = "h",
        "ver" == this.options.dir && (this.dir = "v"),
        this.gesture = new gesture(c,this.dir,{
            begin: function(a, b) {
                g.begin && g.begin(),
                f.root.removeClass("automove")
            },
            moving: function(a, b) {
                e.call(h, a, b)
            },
            end: function(a, b) {
                f.root.addClass("automove"),
                d.call(h, a, b),
                g.end && g.end()
            }
        })
    }
    var g = new b(c("<div></div>"));
    return f.root = c("body"),
    f.root.addClass("automove"),
    f.prototype = {
        moving: e,
        end: d,
        next: function(a) {
            var b = this._currentIndex + (a || 1);
            return this.options.cycle && (b = (b + this.pages.length) % this.pages.length),
            this.pages[b] || g
        },
        current: function() {
            return this.pages[this._currentIndex] || g
        },
        prev: function(a) {
            var b = this._currentIndex - (a || 1);
            return this.options.cycle && (b = (b + this.pages.length) % this.pages.length),
            this.pages[b] || g
        },
        nextPage: function() {
            var a = this.prev()
              , b = this.next()
              , c = this.current();
            if (c.hide("prev"),
            b.show("current"),
            this.options.bigBuffer ? (a.hide("prev2"),
            this.next(2).hide("next")) : (a.hide("full"),
            this.next(2).prepare()),
            this._currentIndex++,
            this.options.cycle) {
                this._currentIndex = this._currentIndex % this.pages.length;
                var d = this;
                d.next().dom.css("display", "none"),
                setTimeout(function() {
                    setTimeout(function() {
                        d.next().dom.css("display", "")
                    }, 10),
                    d.next().hide("next")
                }, 10)
            }
            this.options.changed && this.options.changed(this._currentIndex)
        },
        prevPage: function() {
            var a = this.prev()
              , b = this.next()
              , c = this.current();
            c.hide("next"),
            a.show("current"),
            this.options.bigBuffer ? (b.hide("next2"),
            this.prev(2).hide("prev")) : (b.hide("full"),
            this.prev(2).prepare()),
            this._currentIndex--,
            this.options.cycle && (this._currentIndex = (this._currentIndex + this.pages.length) % this.pages.length),
            this.options.changed && this.options.changed(this._currentIndex)
        },
        goPage: function(a) {
            for (var b = 0; b < this.pages.length; b++)
                this.pages[b].dom.removeClass("prev").removeClass("current").removeClass("next");
            for (var b = 0; a > b; b++)
                this.pages[b].dom.addClass("prev");
            this.pages[b].dom.addClass("current");
            for (var b = a + 1; b < this.pages.length; b++)
                this.pages[b].dom.addClass("next");
            this._currentIndex = a,
            this.current().prepare(),
            this.next().prepare(),
            this.prev().prepare(),
            this.options.end && this.options.end()
        },
        destory: function() {
            this.options = null ,
            this.pages = null ,
            this.gesture.destory(),
            this.gesture = null
        },
        active: function(a) {
            this.gesture.active(a),
            a && this.pages[this._currentIndex].show()
        },
        constructor: f
    },
    f
});
