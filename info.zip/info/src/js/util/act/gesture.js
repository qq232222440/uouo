define(["lib/zepto.js"], function(a) {
    function b(b) {
        if (o && (!n || !document.ontouchmove)) {
            if (b.touches)
                var c = b.touches[0];
            else
                var c = b;
            m = c.target
            f = c.clientX
            g = c.clientY
            e = 0
            j = null 
            h = a(m).closest(".v_gesture_,._gesture_")
            i = a(m).closest(".h_gesture_,._gesture_")
			console.log(i)
            h && (h = h.data("v_gesture_"))
            i && (i = i.data("h_gesture_"))
			console.log(m,a(m))
            n = !0
        }
    }
    function c(a) {
        if (n || document.ontouchmove) {
            if (a.touches)
                var b = a.touches[0];
            else
                var b = a;
            var c = b.clientX
              , d = b.clientY;
            k = c - f
            l = d - g
			if(e<=0)
			{
				if(i && Math.abs(c - f) > 0 && Math.abs(d - g) / Math.abs(c - f) < 3)
				{
					if(i)
					{
						e = 1,
						j = i,
						i.options.begin && i.options.begin.call(i.context, k, l, a)
					}
					else
					{
						e = -1
					}
				}
				else
				{
					if( h && Math.abs(d - g) > 5)
					{
						if(h)
						{
							e = 2,
							j = h,
							h.options.begin && h.options.begin.call(h.context, k, l, a)
						}
						else
						{
							e = -1
						}
					}

				}
				
			}
			if(e>0)
			{
				console.log(j.options)
				j.options.moving && j.options.moving.call(j.context, k, l, a, e)
				j && a.preventDefault()
			}

        }
    }
    function d(b) {
        if (0 == e) {
            if (0 != a(b.target).closest("a").length)
                return;
            var c = a(m).closest(".tap_gesture_").data("tap_gesture_");
            c && c.options.tap && c.options.tap.call(c.context, b)
        }  
		else if(e > 0 )
		{
			j.options.end && j.options.end.call(j.context, k, l, b);
		}
            
        n = !1
    }
    var e, f, g, h, i, j, k, l, m, n = !1, o = !0;
	
	if(document.ontouchmove!==void 0)
	{
		document.documentElement.addEventListener("touchstart", b)
		document.documentElement.addEventListener("touchmove", c)
		document.documentElement.addEventListener("touchend", d)
	}
    else
	{
		document.documentElement.addEventListener("mousedown", b)
		document.documentElement.addEventListener("mousemove", c)
		document.documentElement.addEventListener("mouseup", d)
	}
    var p = function(a, b, c) {
		
        this.dom = a
        this.action = b || ""
        this.options = c || {}
        this.context = c.context
		console.log("-----------------",this)
        this.dom.addClass(this.action + "_gesture_")
		if("" == this.action || "v" == this.action)
		{
			this.dom.data("v_gesture_", this)
		}
		else if("" == this.action || "h" == this.action)
		{
			this.dom.data("h_gesture_", this)
		}
		else if("tap" == this.action)
		{
			this.dom.data("tap_gesture_", this)
		}
    }
    ;
    return p.prototype = {
        active: function(a) {
            a ? this.dom.addClass(this.action + "_gesture_") : this.dom.removeClass(this.action + "_gesture_")
        },
        destory: function() {
            this.dom.removeClass(this.action + "_gesture_"),
            "" == this.action || "v" == this.action ? this.dom.data("v_gesture_", void 0) : "" == this.action || "h" == this.action ? this.dom.data("h_gesture_", void 0) : "tap" == this.action && this.dom.data("tap_gesture_", void 0)
        },
        constructor: p
    },
    p.active = function(a) {
        o = a
    }
    ,
    p
});