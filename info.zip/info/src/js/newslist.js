define(["lib/zepto.js","lib/juicer.js","api.js",],function($,juicer,api){
	var host =  window.location.hostname,
		updateFlag = true,
		refreshFlag = true,//屏蔽置顶刷新导致页面全部刷新
		lastTime,
		typeNum = 1,//menu类型
		pageNum = 0;//页数
	var win= $(window);
	var pwd,uid,utype;
	var list = {
		init:function(){
			var arr=[{
				"name":"热点",
				"id":"1"
				},
				{
					"name":"科技",
					"id":"4"
				},
				{
					"name":"美女",
					"id":"26"
				},
				{
					"name":"健康",
					"id":"24"
				},
				{
					"name":"育儿",
					"id":"16"
				},
				{
					"name":"社会",
					"id":"2"
				},
				{
					"name":"财经",
					"id":"7"
				},
				{
					"name":"体育",
					"id":"6"
				},
				{
					"name":"汽车",
					"id":"5"
				},
				{
					"name":"国际",
					"id":"9"
				},
				{
					"name":"时尚",
					"id":"10"
				},
				{
					"name":"探索",
					"id":"14"
				},
				{
					"name":"科学",
					"id":"25"
				},
				{
					"name":"娱乐",
					"id":"3"
				},
				{
					"name":"趣图",
					"id":"23"
				},
				{
					"name":"搞笑",
					"id":"21"
				},
				{
					"name":"养生",
					"id":"17"
				},
				{
					"name":"游戏",
					"id":"11"
				},
				{
					"name":"互联网",
					"id":"22"
				},
				{
					"name":"股票",
					"id":"20"
				},
				{
					"name":"军事",
					"id":"8"
				},
				{
					"name":"历史",
					"id":"13"
				},
				{
					"name":"故事",
					"id":"18"
				},
				{
					"name":"旅游",
					"id":"12"
				},
				{
					"name":"美文",
					"id":"19"
				},
				{
					"name":"美食",
					"id":"15"
				},
				{
					"name":"外媒",
					"id":"29"
				},
				{
					"name":"影视",
					"id":"30"
				},
				{
					"name":"奇闻",
					"id":"31"
				},
				{
					"name":"萌宠",
					"id":"32"
				},
				{
					"name":"App",
					"id":"35"
				},
				{
					"name":"自媒体",
					"id":"36"
				}
			]
			//资讯顶部menu
			this.fillTitle(arr);
			//资讯内容
			this.fillContent();
			//置顶menu
			this.topShow();
			//上拉加载数据
			this.upData();
			//图片加载
			this.loadAreaImage();
			//document.body.addEventListener("touchmove",function(e){
			//	console.log(e.targetTouches[0].clientY);
			//})
		},
		/***
		 * 填menu内容
		 * @param dt
         */
		fillTitle: function (dt) {
			var tpl = document.getElementById("channel").innerHTML;
			document.querySelector(".top-channel").innerHTML=juicer(tpl,{"list":dt});
			document.querySelector(".fixed-channel").innerHTML=juicer(tpl,{"list":dt});
			var self = this,ele=$(".top-channel,.fixed-channel");;
			//频道切换
			$(".top-channel>a,.fixed-channel>a").on("click",function(){
				var me = $(this),
					idx = me.index(),
					id = me.data("id");

				typeNum = id;
				refreshFlag = false;
				$(".top-channel>a,.fixed-channel>a").each(function(){
					$(this).removeClass("active")
					$(".i-more").removeClass("updown");
				})
				me.addClass("active");
				$(".fixed-channel>a").eq(idx).addClass("active")
				ele.css("height",h);
				ele.data("flag",false);
				self.getInfoDt(id,0);
				var hh = $(".info-content").offset().top;
				window.scrollTo(0,hh);
			});
			var hasflag, h;
			$(".btn-more").on("click",function(){
				var self = $(this);
				hasflag = ele.data("flag");
				if(hasflag)
				{
					$(".i-more").removeClass("updown");
					ele.data("flag",false);
					self.next().css("height",h);
				}
				else
				{
					$(".i-more").addClass("updown");
					h = self.next().height();
					self.next().css("height","inherit");
					ele.data("flag",true);
				}
			})
		},
		/***
		 * 填充内容
		 */
		fillContent: function (flag) {
			var self = this;
			if(self.getCookie('Authorization')&&self.getCookie('Authorization')!="null")
			{
				self.getInfoDt(typeNum, pageNum);
			}
			else
			{
				api.sign(function (data, status, xhr) {
					if (data.code == 2000) {
						pwd = data.data.password;
						uid = data.data.uid;
						var Authorization = $.isPC()?xhr.getResponseHeader('Authorization'):data.token;
						self.setCookie('Authorization', Authorization);
						self.getInfoDt(typeNum, pageNum);

						//api.cloverPost("http://bdp.deeporiginalx.com/v2/au/lin/g",JSON.stringify({
						//	"uid": uid,
						//	"password": pwd
						//}),function(data){
						//	alert(data);
						//})
					}

				});
			}
		},
		/***
		 * 获取资讯数据
		 * @param type
         */
		getInfoDt:function(type,page,time){
			var self = this,
				times = time||(new Date()).getTime();
			var getFlag = true;
			$(".i-top").addClass("action");
			api.newslist(type,times,page,function(data){
				if(data.code==4003&&getFlag)
				{
					//首次登陆
					if(!uid||!pwd)
					{

					}
					api.login(uid,pwd,function(data, status, xhr){

						if(data.code==2000)
						{
							getFlag = false;
							var Authorization=$.isPC()?xhr.getResponseHeader('Authorization'):data.token;
							self.setCookie('Authorization',Authorization);
							if(Authorization==null)
							{
								console.error("null");
								return false;
							}
							self.getInfoDt(typeNum,pageNum);
						}
					})

					//api.cloverPost("http://bdp.deeporiginalx.com/v2/au/lin/g",JSON.stringify({
					//	"uid": uid,
					//	"password": pwd
					//}),function(data){
					//	alert(data);
					//})
				}
				if(data.code==2000)
				{
					//点击获取数据后刷新
					$(".i-top").removeClass("action");
					if(!time)
					{
						$(".con-list").empty();
					}
					refreshFlag = true;
					updateFlag = true;
					//pageNum++;
					var dt = data.data;
					lastTime = toDateTime(dt[dt.length-1].ptime);

					$(".bottom-tip").remove();
					data.data.forEach(function(dd){
						dd.ptime = self.formatTime(dd.ptime);
					});
					var tpl = document.getElementById("newslist").innerHTML;
					var str = document.querySelector(".con-list").innerHTML;
					document.querySelector(".con-list").innerHTML=str+(juicer(tpl,{"list":dt}))+'<div class="bottom-tip">加载中.....</div>';
					//提前显示默认高度内的图片
					if(win.scrollTop()<1004)
					{
						for(var i=0;i<12;i++)
						{
							var img = $(".img-news").find("img");
							img.eq(i).attr("src",img.eq(i).data("src"));
							img.on("load",function(e){
								e.target.style.opacity = 1,
									e.target.style.background = "none"
							})
						}
					}
					setTimeout(function(){
						$(".top-tip").removeClass("upmove");
					},5000);
				}
			},null,function(request){
				request.setRequestHeader("Authorization", self.getCookie('Authorization'));
			});
			function toDateTime(time){
				var t = time.replace(/:/g,"-"),
					t = t.replace(/ /g,"-"),
					arr = t.split("-");
				var currTime = new Date(arr[0],parseInt(arr[1])-1,arr[2],arr[3],arr[4],arr[5]);
				return currTime.getTime()


			}
		},
		/****
		 * 置顶显示
		 */
		topShow:function(){
			var self = this;
			var objTop = $(".con-list").offset().top-$(".top-channel").height(),
				conListTop = $(".con-list").css("top"),
				ele = $(".top-channel,.fixed-channel");
			function showTopIcon(){
				//$(".info-content").css({"position":"absolute","top":"-20px"})
				$(".fixed-top").css({"display":"block"})
				//$(".con-list").css("top","0");
				$(".top-channel").css("opacity",0)
				$(".info-content .btn-more").hide();
			}

			var flag =true
			function waitFunc(func,wait,time)
			{
				var timeout,startTime = new Date();
				return function(){
					var self = this,
						args = arguments,
						currTime = new Date();

					if(flag&&document.body.scrollTop>=objTop)
					{
						//上拉能跟上显示
						flag = false
						clearTimeout(timeout);
						timeout = setTimeout(func,wait);
						$(".btn-top").show();

					}
					if(refreshFlag&&document.body.scrollTop <objTop)
					{
						flag = true;
						clearTimeout(timeout);
						$(".info-content").css({"position":"relative","top":"0"}).show();
						$(".fixed-top,.btn-top").hide();
						$(".top-tip").removeClass("upmove");
						//$(".con-list").css("top",conListTop)
						$(".info-content .btn-more").show();
						$(".top-channel").css("opacity",1)
					}
					$(".i-more").removeClass("updown");
					ele.data("flag",false).attr("style","");//滚动隐藏频道
					//else if(document.body.scrollTop<=0)
					//{
					//	flag = true;
					//	clearTimeout(timeout);
					//	$(".btn-top").hide();
					//	$(".info-content").css({"position":"relative","top":"0"})
					//	$(".fixed-channel").hide();
					//}
					//if(currTime-startTime>=time)
					//{
					//	func.apply(self,args);
					//	startTime = currTime;
					//}
					//else
					//{
					//
					//}
				}
			}
			window.addEventListener("scroll",waitFunc(showTopIcon,100,500));
			$(".btn-top").on("click",function(){
				refreshFlag = false;
				self.getInfoDt(typeNum,0);
				var hh = $(".info-content").offset().top;
				window.scrollTo(0,hh);
				$(".top-tip").addClass("upmove").css({transition: "all 300ms ease-in"});

			})
		},
		upData:function(){
			var self = this;
			function upRefreshData(){
				var h=0;

				$(".con-list .bl").each(function (dd) {
					h = h+$(this).height();
				})
				if(updateFlag && document.body.scrollTop>=(h-1900))
				{
					updateFlag = false;
					self.getInfoDt(typeNum,pageNum,lastTime);
				}
			}
			function delayFunc(func,wait,time)
			{
				var timeout,startTime = new Date();
				return function(){
					var self = this,
						args = arguments,
						currTime = new Date();
						clearTimeout(timeout);
					if(currTime-startTime>=time)
					{
						func.apply(self,args);
						startTime = currTime;
					}
					else
					{
						timeout = setTimeout(func,wait);
					}
				}
			}
			window.addEventListener("scroll",delayFunc(upRefreshData,500,1000));
		},
		/****
		 * 格式化时间
		 * @param time
		 * @returns {string|*}
         */
		formatTime:function(time){
			var currTime = new Date().getTime(),
				times= Date.parse(new Date(time)),
				nowTimeStr,
				nowTime = parseInt((currTime-times)/1000);
			//nowTimeStr = nowTime+"秒前"
			nowTimeStr = "刚刚"
			if(nowTime>60){
				nowTimeStr = parseInt(nowTime/60)+"分钟前"
			};
			if(nowTime>60*60){
				nowTimeStr = parseInt(nowTime/(60*60))+"小时前"
			};
			if(nowTime>60*60*24){
				nowTimeStr = "昨天 "+time.substr(10,6)
			};
			if(nowTime>60*60*48){
				nowTimeStr = time.substr(6,11)
			};
			return nowTimeStr;
		},
		loadAreaImage: function () {

			window.addEventListener("scroll",function(){

				for(var i=0;i<$("img").size();i++)
				{
					showImg($("img").eq(i));
				}
			})
			function showImg(target)
			{
				var d = win.scrollTop()
				, e = d + win.height()
				, h = target.offset().top;
				if (h >= d && h <= e) {
					var src = target.data("src");
					target.attr("src",src);
					target.on("load",function(e){
						e.target.style.opacity = 1,
							e.target.style.background = "none"
					})
				}
			}
		},
		setCookie:function(name,val,domain,path,hour){
			var date = new Date(),expire=new Date();
			expire.setTime(date.getTime()+3600000*hour);
			window.document.cookie = name+"="+val+";"+(hour?("expire="+expire.toGMTString()+";"):"")+(path?("path="+path+";"):"path=/;")+ (domain ? ("domain=" + domain + ";") : ("domain=" + host + ";"))
		},
		getCookie:function(name){
			var reg = new RegExp("(?:^|;+|\\s+)" + name + "=([^;]*)");
			var m = window.document.cookie.match(reg);
			return (!m?"":m[1]);
		},
		remove:function(name,domain,path){
			window.document.cookie = name + "=; expires=Mon, 26 Jul 1997 05:00:00 GMT; " + (path ? ("path=" + path + "; ") : "path=/; ") + (domain ? ("domain=" + domain + ";") : ("domain=" + host + ";"));
		},
		clearAllCookie:function(){
			var keys=document.cookie.match(/[^ =;]+(?=\=)/g);
			if (keys) {
				for (var i =  keys.length; i--;)
					document.cookie=keys[i]+'=0;expires=' + new Date(0).toUTCString()
			}
		}
	}
	return list;
})
