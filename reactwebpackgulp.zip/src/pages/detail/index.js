module.exports = require('./detail');
