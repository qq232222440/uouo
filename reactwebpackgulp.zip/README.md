# webpack es6 react 项目基础工程

---


## clone 到本地
* clone 代码
``` git clone xxx ```
* 安装依赖
 ``` tnpm install(tnpm install||npm install) ```


* 启动本地服务
``` gulp server ```
* 项目构建
 ```gulp```

## 目录介绍
* build 构建后的代码
* html  具体页面
* app 入口文件
* src 静态资源
  * css 前端样式,使用 less
  * images 图片文件夹
  * pages 页面路由模块js
  * componets 组件
  

* gulpfile.js 构建配置文件
* webpack.config.js webpack 配置文件
##待完善..